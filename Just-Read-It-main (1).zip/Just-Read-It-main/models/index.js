module.exports = {
    Story: require('./story'),
    User: require('./user')
};


